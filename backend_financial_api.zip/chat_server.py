import requests
from flask import Flask, request, jsonify

app = Flask(__name__)

API_KEY = 'YOUR_ALPHA_VANTAGE_API_KEY'  # Înlocuiește cu cheia ta Alpha Vantage

def get_financial_data(symbol):
    url = f"https://www.alphavantage.co/query?function=OVERVIEW&symbol={symbol}&apikey={API_KEY}"
    response = requests.get(url)
    data = response.json()

    if "Symbol" in data:
        try:
            return {
                "Symbol": data.get("Symbol"),
                "EBITDA": data.get("EBITDA"),
                "Total Revenues": data.get("RevenueTTM"),
                "Gross Profit": data.get("GrossProfitTTM"),
                "ROE": data.get("ReturnOnEquityTTM"),
                "ROA": data.get("ReturnOnAssetsTTM"),
                "PE Ratio": data.get("PERatio"),
                "EV/EBITDA": data.get("EVToEBITDA"),
                "Debt/Equity": data.get("DebtEquity"),
                "Current Ratio": data.get("CurrentRatio"),
                "Net Income": data.get("NetIncomeTTM"),
                "WACC": data.get("WeightedAverageCostOfCapitalTTM", "N/A")  # Exemplu
            }
        except KeyError:
            return {"error": "Indicatorii lipsesc din răspuns"}
    else:
        return {"error": "Nu s-au găsit date pentru simbolul oferit"}

@app.route('/financial_analysis', methods=['POST'])
def financial_analysis():
    data = request.get_json()
    symbol = data.get('symbol', '').upper()
    if not symbol:
        return jsonify({"error": "Lipsește simbolul companiei"})
    result = get_financial_data(symbol)
    return jsonify(result)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)